# Appointed Hour for Android

A native Android shell around the Appointed Hour web app (all of the Bible text, games, plans and journal work offline inside it).
The native part adds what a web page cannot do:

- Alarms and notifications at your appointed times, even when the app is closed (Reminders.kt)
- App lock: at an appointed time, chosen apps are covered by the lock screen until you read or pray (LockAccessibilityService.kt: notices a chosen app opening and covers it, like Pause-style blockers)

## Get an APK without Android Studio
1. Create a free GitHub account and a new empty repository.
2. Upload every file in this folder to it (keep the folder structure, including `.github/workflows/android.yml`).
3. Open the repository's Actions tab, run "Build APK", and download `AppointedHour-debug-apk` when it finishes.
4. Install the APK on your phone (allow installs from your browser or Files app when asked).

## Or build in Android Studio
Open this folder, let Gradle sync, press Run.

## First run on the phone
1. Open the app, then the You tab, then App lock.
2. Tap Turn on next to Accessibility. In Settings find Appointed Hour lock and switch it on. If the switch is greyed out, open the app's info page, tap the three dots, and choose Allow restricted settings, then try again.
3. Tick "Cover chosen apps at appointed times" and choose the apps to lock.
4. Add your appointed times on the same page.

## Not in this first version
- Accounts, sync across devices, Community groups and the Claude-written devotionals, prayers and questions need an online service (the web version gets them from Claude). In the app the built-in questions and prayers are used.
- Alarms are inexact (they can fire a few minutes late) to avoid a special permission. Exact alarms can be added later.
- Play Store rules on the Accessibility service are strict. It is fine for installing the APK yourself, but a Play Store release needs a prominent disclosure and approval.
- Some phone makers stop background services aggressively. If the lock stops working, set battery use for the app to Unrestricted.
- Play Store release needs a proper icon, a privacy policy, and a written justification for usage access and overlay permissions.
