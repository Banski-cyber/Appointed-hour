# Appointed Hour for Android

A native Android shell around the Appointed Hour web app (all of the Bible text, games, plans and journal work offline inside it).
The native part adds what a web page cannot do:

- Alarms and notifications at your appointed times, even when the app is closed (Reminders.kt)
- App lock: at an appointed time, chosen apps are covered by the lock screen until you read or pray (LockAccessibilityService.kt: notices a chosen app opening and covers it, like Pause-style blockers)

## Get an APK without Android Studio
1. Create a free GitHub account and a new empty repository.
2. Upload every file in this folder to it (keep the folder structure, including `.github/workflows/android.yml`).
3. Open the repository's Actions tab, run "Build APK", and download `AppointedHour-debug-apk` when it finishes.
4. Install the APK on your phone (allow installs from your browser or Files app when asked).

## Or build in Android Studio
Open this folder, let Gradle sync, press Run.

## First run on the phone
1. Open the app, then the You tab, then App lock.
2. Tap Turn on next to Accessibility. In Settings find Appointed Hour lock and switch it on. If the switch is greyed out, open the app's info page, tap the three dots, and choose Allow restricted settings, then try again.
3. Tick "Cover chosen apps at appointed times" and choose the apps to lock.
4. Add your appointed times on the same page.

## Offline: how the content works
- Everything works offline. Nothing depends on Claude or an internet connection.
- Devotionals: 10 built-in devotionals, each paired with its own verse, which is shown in your chosen Bible version.
- Prayers: the prayer writer reads what you said or typed, picks matching themes (worry, family, healing, guidance, forgiveness, work, grief and more), and builds a prayer for the time of day. "I need help praying" gives a short prayer that changes daily.
- Reflection: after you read, the app asks a question drawn from the chapter, and checks that your answer is a real sentence about the passage or your day.
- Chapter explanations: 12 chapters have written notes. Every other chapter gets a summary of its book, quotes from the chapter, and three questions.
- Progress (streak, reading, journal, settings) is saved on the device. No account required.

## Still limited in this version
- Community groups and cross-device sync are not available offline.
- Alarms are inexact (they can fire a few minutes late) to avoid a special permission.
- Play Store rules on the Accessibility service are strict. Self-installing the APK is fine; a Play Store release needs disclosure and approval.
- Some phone makers stop background services. Set battery use for the app to Unrestricted if the lock stops working.

## Accounts, sync and Community (Supabase)
- Sign in or create an account under the You tab. It is optional. Everything else works offline.
- Progress (streak, XP, journal, notes, highlights, plans, memory verses) is saved to the account and merges across phones.
- Community groups read and write posts in Supabase. Posts have Amen, Report (saved to the `reports` table, which you review in Supabase) and Delete for your own posts.
- Only the public project URL and the publishable key are in the app. Never put the secret/service_role key in the app.
- In Supabase, Authentication, Providers, Email: if "Confirm email" is on, new people must confirm by email before they can sign in. For testing, turn it off.
