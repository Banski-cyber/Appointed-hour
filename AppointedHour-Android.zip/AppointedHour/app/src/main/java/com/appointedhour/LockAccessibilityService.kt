package com.appointedhour

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.webkit.WebView
import android.widget.FrameLayout
import org.json.JSONArray

/**
 * Notices when a chosen app opens (no polling, no extra permissions) and covers it with the
 * lock screen, drawn as an accessibility overlay. Same approach as "Pause"-style app blockers.
 */
class LockAccessibilityService : AccessibilityService() {
    companion object { var inst: LockAccessibilityService? = null }
    private var overlay: FrameLayout? = null

    override fun onServiceConnected() { inst = this }
    override fun onInterrupt() {}
    override fun onDestroy() { dismiss(); if (inst === this) inst = null; super.onDestroy() }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || overlay != null) return
        val s = sp(this)
        if (!s.getBoolean("lockOn", false) || !s.getBoolean("locked", false)) return
        val arr = JSONArray(s.getString("blocked", "[]")!!)
        for (i in 0 until arr.length()) if (arr.getString(i) == pkg) { show(); return }
    }

    private fun show() {
        val wm = getSystemService(WindowManager::class.java)
        val root = object : FrameLayout(this) {
            override fun dispatchKeyEvent(ev: KeyEvent): Boolean {
                if (ev.keyCode == KeyEvent.KEYCODE_BACK) {      // back goes Home, never to the locked app
                    if (ev.action == KeyEvent.ACTION_UP) performGlobalAction(GLOBAL_ACTION_HOME)
                    return true
                }
                return super.dispatchKeyEvent(ev)
            }
        }
        val web = WebView(this).also { it.setupApp(this); it.loadUrl("file:///android_asset/index.html#lock") }
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        wm.addView(root, lp)
        overlay = root
    }

    fun dismiss() {
        val o = overlay ?: return
        overlay = null
        (o.getChildAt(0) as? WebView)?.destroy()
        getSystemService(WindowManager::class.java).removeView(o)
    }
}
