package com.appointedhour

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

object Reminders {
    const val CHANNEL = "ah_reminders"

    private fun pi(c: Context, t: String) = PendingIntent.getBroadcast(
        c, t.replace(":", "").toInt(), Intent(c, ReminderReceiver::class.java).putExtra("t", t),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** One alarm per appointed time (HH:MM). Each alarm re-schedules itself for the next day. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val p = sp(c)
        p.getStringSet("sched", emptySet())!!.forEach { am.cancel(pi(c, it)) }
        val times = p.getStringSet("times", emptySet())!!.toSet()
        times.forEach { t ->
            val (h, m) = t.split(":").map { it.toInt() }
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(c, t))
        }
        p.edit().putStringSet("sched", times).apply()
    }

    fun notify(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Appointed times", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(7, NotificationCompat.Builder(c, CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Time with God").setContentText("It’s time. Read a chapter or pray.")
            .setContentIntent(open).setAutoCancel(true).build())
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        sp(c).edit().putBoolean("locked", true).apply()   // chosen apps stay covered until the person finishes
        Reminders.notify(c)
        Reminders.schedule(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Reminders.schedule(c)
    }
}
