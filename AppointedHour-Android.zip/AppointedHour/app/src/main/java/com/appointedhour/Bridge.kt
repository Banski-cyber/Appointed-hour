package com.appointedhour

import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

fun sp(c: Context) = c.getSharedPreferences("ah", Context.MODE_PRIVATE)

@SuppressLint("SetJavaScriptEnabled")
fun WebView.setupApp(c: Context) {
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    addJavascriptInterface(Bridge(c), "Android")
}

/** Everything the web app can ask the phone to do. Exposed to JavaScript as `window.Android`. */
class Bridge(private val c: Context) {
    @JavascriptInterface fun setReminders(json: String) {
        val a = JSONArray(json); val s = HashSet<String>()
        for (i in 0 until a.length()) s.add(a.getString(i))
        sp(c).edit().putStringSet("times", s).apply(); Reminders.schedule(c)
    }
    @JavascriptInterface fun listApps(): String {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val arr = JSONArray()
        pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != c.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { arr.put(JSONObject().put("n", it.loadLabel(pm).toString()).put("p", it.activityInfo.packageName)) }
        return arr.toString()
    }
    @JavascriptInterface fun setBlocked(json: String) { sp(c).edit().putString("blocked", json).apply() }
    @JavascriptInterface fun getBlocked(): String = sp(c).getString("blocked", "[]")!!
    @JavascriptInterface fun isLockEnabled(): Boolean = sp(c).getBoolean("lockOn", false)
    @JavascriptInterface fun setLockEnabled(on: Boolean) {
        sp(c).edit().putBoolean("lockOn", on).apply()
        val i = Intent(c, LockService::class.java)
        if (on) ContextCompat.startForegroundService(c, i) else c.stopService(i)
    }
    @JavascriptInterface fun hasUsage(): Boolean {
        val ao = c.getSystemService(AppOpsManager::class.java)
        return ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }
    @JavascriptInterface fun hasOverlay(): Boolean = Settings.canDrawOverlays(c)
    @JavascriptInterface fun openUsage() { c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    @JavascriptInterface fun openOverlay() {
        c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    /** Called by the web app when the person finishes reading or praying. */
    @JavascriptInterface fun onCompleted() {
        sp(c).edit().putBoolean("locked", false).apply()
        LockActivity.current?.let { a -> a.runOnUiThread { a.finish() } }
    }
}
