package com.appointedhour

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView

/** Full-screen cover shown on top of a locked app. Loads the same web app, starting on the lock screen. */
class LockActivity : Activity() {
    companion object { var current: LockActivity? = null }
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); current = this
        WebView(this).also { setContentView(it); it.setupApp(this); it.loadUrl("file:///android_asset/index.html#lock") }
    }
    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {   // back goes Home, never to the locked app
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
