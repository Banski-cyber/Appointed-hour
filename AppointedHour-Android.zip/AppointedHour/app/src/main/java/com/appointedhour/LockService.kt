package com.appointedhour

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import org.json.JSONArray

/** Watches which app is in front. While an appointed time is unfinished, chosen apps are covered by LockActivity. */
class LockService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var cur = ""
    private val tick = object : Runnable { override fun run() { check(); h.postDelayed(this, 800) } }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("ah_lock", "App lock", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, NotificationCompat.Builder(this, "ah_lock").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Appointed Hour").setContentText("App lock is on").build())
        h.removeCallbacks(tick); h.post(tick)
        return START_STICKY
    }

    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }

    @Suppress("DEPRECATION")
    private fun foreground(): String? {
        val um = getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - 5000, now); val e = UsageEvents.Event(); var p: String? = null
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) p = e.packageName }
        return p
    }

    private fun check() {
        val s = sp(this)
        if (!s.getBoolean("locked", false)) return
        foreground()?.let { cur = it }
        val arr = JSONArray(s.getString("blocked", "[]")!!)
        val list = (0 until arr.length()).map { arr.getString(it) }
        if (cur in list && cur != packageName) {
            startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            cur = packageName
        }
    }
}
